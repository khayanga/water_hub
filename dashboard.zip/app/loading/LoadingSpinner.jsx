import Spinner from '@/components/Spinner'
import React from 'react'

const LoadingSpinner = () => {
  return (
    <Spinner/>
  )
}

export default LoadingSpinner